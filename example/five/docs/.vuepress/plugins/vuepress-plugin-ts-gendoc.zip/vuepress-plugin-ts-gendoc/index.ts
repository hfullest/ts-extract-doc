import { Plugin, PluginEntry } from "vuepress/config";
import { resolve } from "path";
import parser from "react-docgen-typescript";
import {
  markdownRender,
  renderers,
} from "react-docgen-typescript-markdown-render";

export interface ImportConfig<M = any> {
  alias?: Record<string, string>;
  handler?: (md: M) => void;
  /** 手动定义几级内容，默认根据当前上下文来确认 */
  level?: number;
}

export interface MarkdownImportOptions<M = any> {
  importers?: Record<string, ImportConfig<M> | boolean>;
}

const VuePressMarkdownImportPlugin = (options: MarkdownImportOptions = {}) => {
  const { importers = {} } = options;
  return {
    name: "vuepress-plugin-markdown-import",
    extendMarkdown: (md) => {
      md.block.ruler.before(
        "paragraph",
        "@import",
        function importer(state, startLine, endLine) {
          const oldParentType = state.parentType;
          state.parentType = "paragraph";
          const nextLine = startLine + 1;
          const content = state
            .getLines(startLine, nextLine, state.blkIndent, false)
            .trim();
          state.line = nextLine;
          const targetReg =
            /@import(:(\S+))?(\s+)(([^\/\s]+)(\/[^\?\s\[\]]+)\??(.*))/;
          const match = targetReg.exec(content);
          if (!match) return false;
          const [
            ,
            ,
            identifier,
            ,
            _roughPath,
            alias,
            restPath,
            paramsStr = "",
          ] = match;
          const importConfig = importers[
            identifier ?? "default"
          ] as ImportConfig<typeof md>;
          if (!importConfig) return false;
          const path = `${importConfig?.alias?.[alias] ?? alias}${restPath}`;
          const paramsEntities =
            paramsStr
              .trim()
              .split("&")
              .map((it) => it.split("=")) ?? [];
          const params = Object.fromEntries(paramsEntities);
          const meta = { identifier, path, params };

          const token = state.push("@import", "import", 0);
          token.markup = "@import";
          token.map = [startLine, state.line];
          token.meta = meta;
          token.content = content;
          token.children = [];
          token.level = importConfig.level ?? state.level;
          state.parentType = oldParentType;
          return true;
        }
      );
      md.renderer.rules["@import"] = function importer(tokens, idx) {
        const token = tokens[idx];
        if (token.type !== "@import") return "";
        const { path, params } = token.meta;
        const componentDocs = parser.parse(path, {
          savePropValueAsString: true,
        });
        const mdDoc = markdownRender(componentDocs, {
          renderer: renderers.aliMaterialRenderer,
          language: "zh_CN",
        });
        const componentTokens = md.parse(mdDoc, {});
        componentTokens.forEach(
          (it) => (it.level = Math.max(it.level + token.level - 3, 0))
        );
        const html = md.renderer.render(componentTokens, {}, {});
        return html.replace(/}}/g, "} }"); // 为了解决vue-loader误把 }} 当做模版字符解析
      };
    },
  } as PluginEntry;
};

const VuePressTsGenDocPlugin: Plugin = (options) => {
  return {
    name: "vuepress-plugin-ts-gendoc",
    extendMarkdown: (md) => {
      (
        VuePressMarkdownImportPlugin({
          importers: {
            "ts-gendoc": {
              alias: {
                "@": resolve(process.cwd(), "src"),
              },
              level: 3,
            },
          },
        }) as any
      ).extendMarkdown(md); // 支持markdown @import 导入语法，并将参数解析到meta
    },
  };
};

export default VuePressTsGenDocPlugin;
